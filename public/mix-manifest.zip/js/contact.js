function contactSubmit(){
    let button = document.getElementById('contact-button');
    button.click();
}